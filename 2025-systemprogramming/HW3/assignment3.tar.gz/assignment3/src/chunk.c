/*--------------------------------------------------------------------*/
/* This file is almost empty, and is provided to enable you to use    */ 
/* the Makefile.                                                      */
/* You are free to modify this file if you want.                      */
/* Even if you do not use this file, please keep it for the Makefile  */
/* and be sure to include it when you submit your assignment.         */
/*--------------------------------------------------------------------*/

#include <stdio.h>