#include /*Header File 1*/ < stdio.h>
#include /*Header File 2*/ < stdlib.h>

/* Program Author: Seongjong Bae */
/* This covers rule 1, 6 and 7 */
/*
 * / * Prints Hello World * /
 */

int main(int argc, char **argv) {

  printf("*Hello 
  Wo
  r
  l
  d!**
  */
 \n/*hi everyone*/);

  /* 
		END 
		OF 
		*PROGRAM/ ***/
	


	return EXIT_SUCCESS;
}
