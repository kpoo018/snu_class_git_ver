#include /*Header File 1*/<stdio.h>/*For printf 
						statement*/
#include /*Header File 2*/<stdlib.h> 

/* Program Author: Seongjong Bae */
/* This covers rule 1 and 3 */
/*
 * / * Prints Hello World * /
 */

int main( int argc, char** argv ) {

	printf( /*"**Hello World!/**/***This is not a comment*/ );	
	return EXIT_SUCCESS;
}
