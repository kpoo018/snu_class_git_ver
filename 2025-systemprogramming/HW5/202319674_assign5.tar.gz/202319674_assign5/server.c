/*---------------------------------------------------------------------------*/
/* server.c                                                                  */
/* Author: Junghan Yoon, KyoungSoo Park                                      */
/* Modified by: Junguk Yang                                                  */
/*---------------------------------------------------------------------------*/
#define _GNU_SOURCE
#include "common.h"
#include "skvslib.h"
#include <arpa/inet.h>
#include <errno.h>
#include <getopt.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
/*---------------------------------------------------------------------------*/
struct thread_args
{
    int listenfd;
    int idx;
    struct skvs_ctx *ctx;

    /*---------------------------------------------------------------------------*/
    /* free to use */

    /*---------------------------------------------------------------------------*/
};
/*---------------------------------------------------------------------------*/
volatile static sig_atomic_t g_shutdown = 0;
/*---------------------------------------------------------------------------*/
#define MAX_MSG_SIZE 4096
void run_client(int client_fd, struct skvs_ctx *ctx)
{
    char rbuf[MAX_MSG_SIZE];   // request buffer
    char wbuf[MAX_MSG_SIZE];   // response buffer
    size_t rlen = 0, wlen = 0;

    while (!g_shutdown) {
        while (1) {
            ssize_t n = read(client_fd, rbuf + rlen, sizeof(rbuf) - 1 - rlen);
            if (n > 0) {
                rlen += n;
                rbuf[rlen] = '\0';
            }
            else if (n == 0) {
                return;
            }
            else {
                if (errno == EINTR) {
                    continue;  
                }
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    continue; 
                }
                perror("read failed");
                return;
            }

            int rc = skvs_serve(ctx, rbuf, rlen, wbuf, &wlen);
            if (rc < 0) {
                perror("skvs_serve failed");
                return;
            }
            if (rc == 0) {
                
                continue;
            }
            break;
        }

        size_t wpos = 0;
        while (wpos < wlen) {
            ssize_t n = write(client_fd, wbuf + wpos, wlen - wpos);
            if (n > 0) {
                wpos += n;
            }
            else {
                if (errno == EINTR) {
                    continue;  // retry
                }
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    continue;  // buffer full, try again
                }
                perror("write failed");
                return;
            }
        }

        /* reset for next request */
        rlen = 0;
        wlen = 0;
        memset(rbuf, 0, sizeof(rbuf));
    }
}

void *
handle_client (void *arg)
{
    TRACE_PRINT ();
    struct thread_args *args = (struct thread_args *)arg;
    struct skvs_ctx *ctx = args->ctx;
    int idx = args->idx;
    int listenfd = args->listenfd;
    /*---------------------------------------------------------------------------*/
    pthread_detach (pthread_self ());
    struct sockaddr client;
    socklen_t clientlen = sizeof (client);

    /*---------------------------------------------------------------------------*/

    free (args);
    printf ("%dth worker ready\n", idx);

    /*---------------------------------------------------------------------------*/
    

    while(!g_shutdown){
        int client_fd = accept(listenfd, &client, &clientlen);

        if(client_fd < 0)
        {
            if (errno == EINTR) {
                if (g_shutdown) break; 
                else continue; 
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                continue;
            }
        
            perror ("accept failed");
            return NULL;
        }

        run_client (client_fd, ctx);

        close (client_fd);
        printf("Connection closed by client\n");
    }
    /*---------------------------------------------------------------------------*/

    return NULL;
}
/*---------------------------------------------------------------------------*/
/* Signal handler for SIGINT */
void
handle_sigint (int sig)
{
    TRACE_PRINT ();
    printf ("\nReceived SIGINT, initiating shutdown...\n");
    g_shutdown = 1;
}
/*---------------------------------------------------------------------------*/
int
main (int argc, char *argv[])
{
    size_t hash_size = DEFAULT_HASH_SIZE;
    char *ip = DEFAULT_ANY_IP;
    int port = DEFAULT_PORT, opt;
    int num_threads = NUM_THREADS;
    int delay = RWLOCK_DELAY;
    int listen_fd, optval;
    struct timeval to;
    /*---------------------------------------------------------------------------*/
    struct sockaddr_in server_addr;
    struct skvs_ctx *ctx;

    /*---------------------------------------------------------------------------*/

    /* parse command line options */
    while ((opt = getopt (argc, argv, "p:t:s:d:h")) != -1)
    {
        switch (opt)
        {
        case 'p':
            port = atoi (optarg);
            break;
        case 't':
            num_threads = atoi (optarg);
            break;
        case 's':
            hash_size = atoi (optarg);
            if (hash_size <= 0)
            {
                perror ("Invalid hash size");
                exit (EXIT_FAILURE);
            }
            break;
        case 'd':
            delay = atoi (optarg);
            break;
        case 'h':
        default:
            printf ("Usage: %s [-p port (%d)] "
                    "[-t num_threads (%d)] "
                    "[-d rwlock_delay (%d)] "
                    "[-s hash_size (%d)]\n",
                    argv[0], DEFAULT_PORT, NUM_THREADS, RWLOCK_DELAY,
                    DEFAULT_HASH_SIZE);
            exit (EXIT_FAILURE);
        }
    }

    /* set listen fd with Reuse addr, port, and timeout options. */
    listen_fd = socket (AF_INET, SOCK_STREAM, 0);
    if (listen_fd == -1)
    {
        perror ("Could not create socket");
        return -1;
    }

    optval = 1;
    if (setsockopt (listen_fd, SOL_SOCKET, SO_REUSEADDR, &optval,
                    sizeof (optval))
        != 0)
    {
        perror ("setsockopt SO_REUSEADDR failed");
        close (listen_fd);
        return -1;
    }
    optval = 1;
    if (setsockopt (listen_fd, SOL_SOCKET, SO_REUSEPORT, &optval,
                    sizeof (optval))
        != 0)
    {
        perror ("setsockopt SO_REUSEPORT failed");
        close (listen_fd);
        return -1;
    }

    /* set timeout for client socket for escape on SIGINT */
    to.tv_sec = TIMEOUT;
    to.tv_usec = 0;
    if (setsockopt (listen_fd, SOL_SOCKET, SO_RCVTIMEO, &to, sizeof (to)) < 0)
    {
        perror ("setsockopt SO_RCVTIMEO failed");
        close (listen_fd);
        return -1;
    }

    /*---------------------------------------------------------------------------*/
    signal (SIGINT, handle_sigint);

    memset (&server_addr, 0, sizeof (server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr (ip);
    server_addr.sin_port = htons (port);
    if (bind (listen_fd, (struct sockaddr *)&server_addr, sizeof (server_addr)) < 0)
    {
        perror ("bind failed");
        close (listen_fd);
        return -1;
    }

    if (listen (listen_fd, num_threads) < 0)
    {
        perror ("listen failed");
        close (listen_fd);
        return -1;
    }

    printf ("Server listening on %s:%d\n", ip, port);

    ctx = skvs_init (hash_size, delay);

    for (int i = 0; i< num_threads; i++)
    {
        struct thread_args *args = malloc (sizeof (struct thread_args));
        if (args == NULL)
        {
            perror ("Failed to allocate memory for thread arguments");
            close (listen_fd);
            return -1;
        }

        args->listenfd = listen_fd;
        args->idx = i;
        args->ctx = ctx;
        if (args->ctx == NULL)
        {
            perror ("Failed to initialize SKVS context");
            free (args);
            close (listen_fd);
            return -1;
        }

        pthread_t tid;
        if (pthread_create (&tid, NULL, handle_client, args) != 0)
        {
            perror ("Failed to create thread");
            skvs_destroy (args->ctx, 0);
            free (args);
            close (listen_fd);
            return -1;
        }

    }

    pause();
    if(g_shutdown)
    {   
        printf("Shutting down server...\n");
        skvs_destroy (ctx, 1); 
        close (listen_fd);
    }
    

    /*---------------------------------------------------------------------------*/

    return 0;
}
