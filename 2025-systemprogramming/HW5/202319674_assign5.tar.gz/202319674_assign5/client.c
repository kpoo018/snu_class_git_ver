/*---------------------------------------------------------------------------*/
/* client.c                                                                  */
/* Author: Junghan Yoon, KyoungSoo Park                                      */
/* Modified by: Junguk Yang                                                  */
/*---------------------------------------------------------------------------*/
#define _GNU_SOURCE
#include "common.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
/*---------------------------------------------------------------------------*/
#define MAX_MSG_SIZE 4096
int
main (int argc, char *argv[])
{
    char *ip = DEFAULT_LOOPBACK_IP;
    int port = DEFAULT_PORT;
    int interactive = 0; /* Default is non-interactive mode */
    int opt;

    /*---------------------------------------------------------------------------*/
    int connected, s, res, len;
    char buf[MAX_MSG_SIZE];
    struct addrinfo hints, *ai, *ai_it;

    /*---------------------------------------------------------------------------*/

    /* parse command line options */
    while ((opt = getopt (argc, argv, "i:p:th")) != -1)
    {
        switch (opt)
        {
        case 'i':
            ip = optarg;
            break;
        case 'p':
            port = atoi (optarg);
            if (port <= 1024 || port >= 65536)
            {
                perror ("Invalid port number");
                exit (EXIT_FAILURE);
            }
            break;
        case 't':
            interactive = 1;
            break;
        case 'h':
        default:
            printf ("Usage: %s [-i server_ip_or_domain (%s)] "
                    "[-p port (%d)] [-t]\n",
                    argv[0], DEFAULT_LOOPBACK_IP, DEFAULT_PORT);
            exit (EXIT_FAILURE);
        }
    }

    /*---------------------------------------------------------------------------*/
    if ((s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
    {
        perror ("socket creation failed");
        return -1;
    }

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    
    char port_str[6];
    snprintf(port_str, sizeof(port_str), "%d", port);

    res = getaddrinfo(ip, port_str, &hints, &ai);
    if (res != 0)
    {
        perror ("getaddrinfo failed");
        close(s);
        return -1;
    }

    connected = 0;
    ai_it = ai;
    while (ai_it != NULL) {
        if (connect(s, ai_it->ai_addr, ai_it->ai_addrlen) == 0){
            connected = 1;
            break;
    }
        ai_it = ai_it->ai_next;
    }
    freeaddrinfo(ai);

    if (!connected) {
        perror("connect failed");
        close(s);
        return -1;
    }

    if(interactive) {
        printf("Connected to %s:%d\n", ip, port);
    } 

    while (1) {
        if(interactive) {
            printf("Enter command: ");
        }
        if(fgets(buf, sizeof(buf), stdin) == NULL)
            break;
        len = strlen(buf);

        size_t wpos = 0;
        while (wpos < len) {
            ssize_t n = write(s, buf + wpos, len - wpos);
            if (n > 0) {
                wpos += n;
            } else {
                if (errno == EINTR) {
                    continue;  // retry
                }
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    continue;  // buffer full, try again
                }
                perror("write failed");
                close(s);
                return -1;
            }
        }
        
        size_t rpos = 0;
        
        while(1){
            res = read(s, buf + rpos, sizeof(buf) - 1 - rpos);
            if (res > 0) {
                rpos += res;
                if (buf[rpos - 1] == '\n' || rpos >= sizeof(buf) - 1) {
                    break; 
                }
            } else if (res == 0) {
                printf("Connection closed by server.\n");
                close(s);
                return 0;
            } else {
                if (errno == EINTR) {
                    continue;  
                }
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    continue;  
                }
                perror("read failed");
                close(s);
                return -1;
            }
        }
        buf[rpos] = '\0'; 
        

        if(interactive) {
            printf("Server reply: ");
        }
        printf("%s", buf);
    }

    close(s);
  
    /*---------------------------------------------------------------------------*/

    return 0;
}
