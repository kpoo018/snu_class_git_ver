
python K-merCountingSorting.py $1 $2