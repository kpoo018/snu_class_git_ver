# 'Nonpathogenic_Escherichia coli ATCC 25922.fna'
# 'Pathogenic_Escherichia coli O104H4.fna'
import sys
import re

k=int(sys.argv[1])
filename = sys.argv[2]
f=open(filename,'r')
g=open("202319674",'w')

chromosomeslist=[]

file_read=f.read()
chromosomeslist=file_read.split('>')

kmercnt={}


for chromosome in chromosomeslist[1:]:
    chromosome=''.join(chromosome.split('\n')[1:])
    chromosome=re.sub("[^ATCG]","",chromosome)
    
    # print(len(chromosome))

    for i in range (0,len(chromosome)-k+1):
        kmer=chromosome[i:i+k]
        if kmer not in kmercnt:
            kmercnt[kmer]=1
        else:
            kmercnt[kmer]+=1
    
for kmer in sorted(kmercnt):
    g.write("%s,%d\n" %(kmer, kmercnt[kmer]))
f.close()
# print('end')


