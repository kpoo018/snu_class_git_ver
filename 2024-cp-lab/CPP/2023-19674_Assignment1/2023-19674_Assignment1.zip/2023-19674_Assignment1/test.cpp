#include <iostream>
#include <string>

using namespace std;

int main() {
    string input;

    getline(cin, input);
    cout << input << endl;

    cin >> input;
    cout << input << endl;

    return 0;
}