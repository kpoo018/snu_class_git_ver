import lark
import os
import time
from berkeleydb import db

# prompt 출력 함수
def prompt():
    print("DB_2023-19674> ", end="") 
    return

# 입력된 query가 ;으로 끝나는지 확인하는 함수. 
# 뒤쪽의 white space는 무시함.
def is_complete_query(query):
    if len(query.strip())>0 and query.strip()[-1] == ";":
        return True
    else:
        return False
    
# query 입력받는 함수
def get_query():
    prompt()
    query = input()

    # '\n'이 포함된 query를 처리
    while  not is_complete_query(query):
        prompt()
        query += (" " + input())
    return query

# query에서 오류가 발생하기 전 query 까지만 리턴
def get_valid_query(query, e):
    # 오류 위치를 기준으로 쿼리를 자름
    error_position = e.pos_in_stream  # 오류가 발생한 위치
    valid_query = " ; ".join(query[:error_position].split(";")[:-1])+" ; "  # 오류 이전까지의 쿼리

    return valid_query

class MyTransformerError(Exception):
    pass


# lark의 Transformer 클래스는 tree 형태로 파싱된 결과를 leaf부터 하나씩 읽으며 token의 이름과 동일한 이름의 함수를 호출해줌
class MyTransformer(lark.Transformer):
    def __init__(self):
        super().__init__()
        self.db_env = db.DBEnv()
        
        db_home = "MyDBs"
        if not os.path.exists(db_home):
            os.makedirs(db_home)

        # DB 환경을 생성
        try:
            self.db_env.open(db_home, db.DB_INIT_MPOOL | db.DB_CREATE | db.DB_INIT_TXN | db.DB_INIT_LOG | db.DB_INIT_LOCK)
        except db.DBError as e:
            prompt()
            print(f"Failed to initialize DB environment: {e}")
            raise

         # __meta__ 데이터베이스 생성
        self.meta_db = db.DB(self.db_env)
        try:
            self.meta_db.open("__meta__", None, dbtype=db.DB_BTREE, flags=db.DB_CREATE | db.DB_EXCL)
            self.meta_db.close()
        except db.DBError as e:
            self.meta_db.close()
  
          
        
    def create_table_query(self, items):

        # 트랜잭션 시작
        txn = self.db_env.txn_begin()
        try:
            # 테이블 생성 시 __meta__ 데이터베이스 열기
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, dbtype=db.DB_BTREE, txn=txn)
            
            # 테이블 이름 추출
            table_name = items[2].children[0].lower()

            # 테이블 중복 확인
            try:
                self._check_table_existence(table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError(f"Create table has failed: {e}")
            
            # 컬럼 정의 추출 및 검증
            schema_columns, not_null_columns = self._extract_and_validate_columns(items)
            
            # 테이블 제약 조건 추출 및 검증
            table_constraints = self._extract_and_validate_constraints(items, schema_columns, txn)

            # 테이블 정보 저장
            table_id = self._save_table_info(table_name, schema_columns, not_null_columns, table_constraints, txn)

            new_db = db.DB(self.db_env)

            # 테이블 데이터베이스 생성
            try:
                new_db.open(table_id, None, dbtype=db.DB_HASH, flags=db.DB_CREATE | db.DB_EXCL, txn=txn)
            except Exception as e:
                new_db.close()
                raise e
            
            # 트랜잭션 커밋
            txn.commit()
            prompt()
            print(f"'{table_name}' table is created")
            new_db.close()
            self.meta_db.close()

        except MyTransformerError as e:
            # 사용자 정의 에러 처리
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)
        except Exception as e:
            # 기타 에러 처리
            txn.abort()
            self.meta_db.close()
            prompt()
            print(f"Failed to create table: {e}")
            raise

    # 테이블 ID 가져오기
    def _get_table_id(self, table_name, txn):
        table_id_key= f"__table_id__:{table_name}".encode()
        if self.meta_db.get(table_id_key, txn=txn):
            return self.meta_db.get(table_id_key, txn=txn).decode()
        else: 
            raise MyTransformerError()
        
    # 테이블 중복 확인
    def _check_table_existence(self, table_name, txn):
        schema_key = f"__table_id__:{table_name}".encode()
        if self.meta_db.get(schema_key,txn=txn):
            raise MyTransformerError("table with the same name already exists")

    # 컬럼 정의 추출 및 검증
    def _extract_and_validate_columns(self, items):
        column_definition_iter = items[3].find_data("column_definition")
        schema_columns = []  # 컬럼 이름 리스트
        not_null_columns = []  # NOT NULL 컬럼 리스트

        for column_definition in column_definition_iter:
            column_name = column_definition.children[0].children[0].lower()
            column_type = column_definition.children[1].children[0].lower()

            
            # 컬럼 이름 중복 확인
            if column_name in schema_columns:
                raise MyTransformerError("Create table has failed: column definition is duplicated")

            # char 타입 길이 검증
            if column_type.startswith("char"):
                char_length = int(column_definition.children[1].children[2])
                if char_length < 1:
                    raise MyTransformerError("Char length should be over 0")
                column_type = f"char({char_length})"

            # 컬럼 정보 저장
            schema_columns.append((f"{column_name}", f"{column_type}"))

            # NOT NULL 확인
            if (
                isinstance(column_definition.children[2], lark.Token)
                and column_definition.children[2].value.lower() == "not"
                and column_definition.children[3].value.lower() == "null"
            ):
                # NOT NULL 컬럼 리스트에 추가
                not_null_columns.append(f"{column_name}")


        return schema_columns, not_null_columns

    # 테이블 제약 조건 추출 및 검증
    def _extract_and_validate_constraints(self, items, schema_columns, txn):
        table_constraints = []
        primary_key_columns = []
        table_constraint_iter = items[3].find_data("table_constraint_definition")

        for table_constraint_definition in table_constraint_iter:
            if table_constraint_definition.children[0].data == "primary_key_constraint":
                # PRIMARY KEY 처리
                if primary_key_columns:
                    raise MyTransformerError("Create table has failed: primary key definition is duplicated")
                primary_key_columns = [
                    col.children[0].lower()
                    for col in table_constraint_definition.children[0].children[2].find_data("column_name")
                ]
                exist_columns = set([col[0] for col in schema_columns])
                for pk_col in primary_key_columns:
                    if pk_col not in exist_columns:
                        raise MyTransformerError(f"Create table has failed:cannot define non-existing column '{pk_col}' as primary key")
                table_constraints.append(f"PRIMARY KEY:{','.join(primary_key_columns)}")

            elif table_constraint_definition.children[0].data == "referential_constraint":
                # FOREIGN KEY 처리
                foreign_key_columns, referenced_table, referenced_columns = self._extract_foreign_key(
                    table_constraint_definition
                )
                try:
                    referenced_table_id = self._get_table_id(referenced_table, txn)
                except MyTransformerError as e:
                    raise MyTransformerError(f"Create table has failed: foreign key references non existing table or column")
                self._validate_foreign_key(foreign_key_columns, referenced_table_id, referenced_columns, schema_columns, txn)
                table_constraints.append(
                    f"FOREIGN KEY:{','.join(foreign_key_columns)}->{referenced_table_id}({','.join(referenced_columns)})"
                )
            
        return table_constraints

    # FOREIGN KEY 추출
    def _extract_foreign_key(self, table_constraint_definition):
        foreign_key_columns = [
            col.children[0].lower()
            for col in table_constraint_definition.children[0].children[2].find_data("column_name")
        ]
        referenced_table = table_constraint_definition.children[0].children[4].children[0].lower()
       
        referenced_columns = [
            col.children[0].lower()
            for col in table_constraint_definition.children[0].children[5].find_data("column_name")
        ]
        return foreign_key_columns, referenced_table, referenced_columns

    # FOREIGN KEY 검증
    def _validate_foreign_key(self, foreign_key_columns, referenced_table_id, referenced_columns, schema_columns, txn):
        # Foreign key 컬럼 존재 여부 확인
        exist_columns = set([col[0] for col in schema_columns])
        for fk_col in foreign_key_columns:
            if fk_col not in exist_columns:
                raise MyTransformerError(f"Create table has failed: cannot define non-existing column '{fk_col}' as foreign key")

        # 참조 테이블 및 컬럼 확인
        ref_schema_key = f"__schema__:{referenced_table_id}".encode()
        ref_schema = self.meta_db.get(ref_schema_key, txn=txn)
        if not ref_schema:
            raise MyTransformerError("Fatal Error: Table ID exist, but schema does not exist.")
        
        # 참조 컬럼 존재 여부 확인
        ref_columns = set([col.split(":")[0] for col in ref_schema.decode().split("|")])
        for ref_col in referenced_columns:
            if ref_col not in ref_columns:
                raise MyTransformerError("Create table has failed: foreign key references non existing table or column")
        
        # 참조 컬럼과 데이터 타입 일치 여부 확인
        schema_column_types = {col[0]: col[1] for col in schema_columns}
        ref_column_types = {col.split(":")[0]: col.split(":")[1] for col in ref_schema.decode().split("|")}
        for fk_col, ref_col in zip(foreign_key_columns, referenced_columns):
            if schema_column_types[fk_col] != ref_column_types[ref_col]:
                raise MyTransformerError("Create table has failed: foreign key references wrong type")



        # 참조 컬럼이 Primary Key인지 확인
        ref_constraints_key = f"__constraints__:{referenced_table_id}".encode()
        ref_constraints = self.meta_db.get(ref_constraints_key, txn=txn)
        if not ref_constraints:
            raise MyTransformerError("Create table has failed: foreign key references non primary key column")

        ref_constraints = ref_constraints.decode()
        primary_key_def = next(
            (c for c in ref_constraints.split("|") if c.startswith("PRIMARY KEY:")), None
        )
        if not primary_key_def:
            raise MyTransformerError("Create table has failed: foreign key references non primary key column")
    
        primary_key_columns = primary_key_def.split(":")[1].split(",")
        if set(primary_key_columns) != set(referenced_columns):
            raise MyTransformerError("Create table has failed: foreign key references non primary key column")

       
    # 테이블 정보 저장
    def _save_table_info(self,  table_name, schema_columns, not_null_columns, table_constraints, txn):
        # 테이블 ID 생성 및 저장
        table_id=self._save_table_id(table_name, txn)
        # 테이블 스키마 저장
        self._save_schema(table_id, schema_columns, txn)
         # 참조 관계 저장
        self._save_references(table_id, table_constraints, txn)
        # 제약 조건 저장
        self._save_constraints(table_id, not_null_columns, table_constraints, txn)

        return table_id
    # 테이블 ID 생성 및 저장
    def _save_table_id(self, table_name, txn):
        table_id = str(hash(table_name+str(time.time()*1000)))+"_"+str(int(time.time()*1000))
        table_id_key = f"__table_id__:{table_name}".encode()
        self.meta_db.put(table_id_key, table_id.encode(), txn=txn)
        return table_id
    # 테이블 스키마 저장
    def _save_schema(self, table_id, schema_columns, txn):
        schema_key = f"__schema__:{table_id}".encode()
        schema_value = "|".join([f"{col}:{col_type}" for col, col_type in schema_columns]).encode()

        # 스키마 저장
        self.meta_db.put(schema_key, schema_value, txn=txn)
    # 참조 관계 저장
    def _save_references(self, table_id, table_constraints, txn):
        for constraint in table_constraints:
            if constraint.startswith("FOREIGN KEY"):
                foreign_key_info = constraint.split(":")[1]
                foreign_key_columns, referenced_table_info = foreign_key_info.split("->")
                referenced_table_id = referenced_table_info.split("(")[0]

                # 참조 관계 업데이트
                ref_key = f"__references__:{referenced_table_id}".encode()
                ref_value = self.meta_db.get(ref_key, txn=txn)
                if ref_value:
                    ref_tables = ref_value.decode().split("|")
                    if table_id not in ref_tables:
                        ref_tables.append(table_id)
                        self.meta_db.put(ref_key, "|".join(ref_tables).encode())
                else:
                    self.meta_db.put(ref_key, table_id.encode(), txn=txn)
    # 테이블 제약 조건 저장
    def _save_constraints(self, table_id, not_null_columns, table_constraints, txn):
        
        if not_null_columns:
            table_constraints.append(f"NOT NULL:{','.join(not_null_columns)}")

        if table_constraints:
            constraints_key = f"__constraints__:{table_id}".encode()
            constraints_value = "|".join(table_constraints).encode()

            # 제약 조건 저장
            self.meta_db.put(constraints_key, constraints_value, txn=txn)


    def drop_table_query(self, items):
        # 트랜잭션 시작
        txn = self.db_env.txn_begin()
        try:
            # 테이블 삭제 시 __meta__ 데이터베이스 열기
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, dbtype=db.DB_BTREE, txn=txn)

            # 테이블 이름 추출
            table_name = items[2].children[0].lower()

            # 테이블 ID 가져오기
            try:
                table_id = self._get_table_id(table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError(f"Drop table has failed: no such table")
            
            # 다른 테이블이 foreign key로 참조하고 있는지 확인
            if self._is_table_referenced(table_id, txn):
                raise MyTransformerError(f"Drop table has failed: '{table_name}' is referenced by another table")

            # 테이블 스키마 및 제약 조건 삭제
            self._delete_table_info(table_name, table_id, txn)

             # 테이블 데이터베이스 삭제
            try:
                self.db_env.dbremove(table_id, None, txn, 0)
            except db.DBError as e:
                raise MyTransformerError(f"Failed to remove database file for table {table_name}: {e}")

            # 트랜잭션 커밋
            txn.commit()
            prompt()
            print(f"'{table_name}' table is dropped")
            self.meta_db.close()
        except MyTransformerError as e:
            # 사용자 정의 에러 처리
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)
        except Exception as e:
            # 기타 에러 처리
            txn.abort()
            prompt()
            print(f"Failed to drop table: {e}")
            self.meta_db.close()
            raise

    # 테이블 참조 여부 확인
    def _is_table_referenced(self, table_id, txn):
        
        ref_key = f"__references__:{table_id}".encode()

        if not self.meta_db.get(ref_key, txn=txn):
            return False
        return True
        

    # 테이블 정보 삭제
    def _delete_table_info(self, table_name, table_id, txn):
        # 테이블 ID 삭제
        table_id_key = f"__table_id__:{table_name}".encode()
        self.meta_db.delete(table_id_key, txn=txn)

        # 스키마 삭제
        schema_key = f"__schema__:{table_id}".encode()
        self.meta_db.delete(schema_key, txn=txn)

        # 참조 관계 삭제
        constraints_key = f"__constraints__:{table_id}".encode()
        constraints=self.meta_db.get(constraints_key, txn=txn)
        if constraints:
            constraints = constraints.decode()
            for constraint in constraints.split("|"):
                if constraint.startswith("FOREIGN KEY"):
                    referenced_table_id = constraint.split("->")[1].split("(")[0]
                    ref_key = f"__references__:{referenced_table_id}".encode()
                    ref_value = self.meta_db.get(ref_key, txn=txn)
                    if not ref_value:
                        continue
                    ref_tables = ref_value.decode().split("|")
                    if table_id not in ref_tables:
                        continue
                    ref_tables.remove(table_id)
                    if ref_tables:
                        self.meta_db.put(ref_key, "|".join(ref_tables).encode(), txn=txn)
                    else:
                        self.meta_db.delete(ref_key, txn=txn)
        
        # 제약 조건 삭제
        try:
            self.meta_db.delete(constraints_key, txn=txn)
        except db.DBNotFoundError as e:
            pass

    def explain_query(self, items):

        txn=self.db_env.txn_begin()
        try:
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, dbtype=db.DB_BTREE, txn=txn)

            # 테이블 이름 추출
            table_name = items[1].children[0].lower()

            # 테이블 ID 가져오기
            try:
                table_id = self._get_table_id(table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError(f"{items[0].capitalize()} table has failed: no such table")

            # 테이블 schema 가져오기 
            schema_key = f"__schema__:{table_id}".encode()
            schema_value = self.meta_db.get(schema_key, txn=txn)
            if not schema_value:
                raise MyTransformerError("Fatal Error: Table ID exist, but schema does not exist.")
            schema_column_types = schema_value.decode().split("|")
            schema_column_types = {col.split(":")[0]:col.split(":")[1] for col in schema_column_types}

            #table constraints 가져오기
            constraints_key = f"__constraints__:{table_id}".encode()
            constraints_value = self.meta_db.get(constraints_key, txn=txn)
            primary_key_columns = []
            foreign_key_columns = []
            not_null_columns = []
            if constraints_value:
                constraints_value = constraints_value.decode().split("|")
                #primary key 가져오기
                primary_key_columns = ",".join([c.split(":")[1] for c in constraints_value if c.startswith("PRIMARY KEY:")]).split(",")
                #foreign key 가져오기
                foreign_key_columns = [c.split(":")[1] for c in constraints_value if c.startswith("FOREIGN KEY:")]
                foreign_key_columns = [fk.split("->")[0] for fk in foreign_key_columns]
                foreign_key_columns = [col for fk in foreign_key_columns for col in fk.split(",")]
                #not null 가져오기
                not_null_columns =",".join([c.split(":")[1] for c in constraints_value if c.startswith("NOT NULL:")]).split(",")

            # schema 출력
            print(f"-"*66)
            print(f" {'column_name':<20} | {'type':<20} | {'null':<4} | {'key':<7} ")
            for column_name, column_type in schema_column_types.items():
                null_value = "N" if column_name in not_null_columns or column_name in primary_key_columns else "Y"
                key_value = []
                if column_name in primary_key_columns:
                    key_value.append("PRI")
                if column_name in foreign_key_columns:
                    key_value.append("FOR")
                key_value = "/".join(key_value)
                print(f" {column_name[:20]:<20} | {column_type[:20]:<20} | {null_value[:4]:<4} | {key_value[:7]:<7} ")
            print(f"-"*66)
            print(f"{len(schema_column_types)} rows in set")

            txn.commit()
            self.meta_db.close()
               
        except MyTransformerError as e:
            # 사용자 정의 에러 처리
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)
        except Exception as e:
            # 기타 에러 처리
            txn.abort()
            self.meta_db.close()
            prompt()
            print(f"Failed to explain table: {e}")
            raise
        return
   

    

    def describe_query(self, items):
        self.explain_query(items)
        return
    
    def desc_query(self, items):
        self.explain_query(items)
        return
    
    def insert_query(self, items):

        txn = self.db_env.txn_begin()
        try:
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, db.DB_BTREE, txn=txn)

            # 테이블 이름 추출
            table_name = items[2].children[0].lower()

            # 테이블 ID 가져오기
            try:
                table_id = self._get_table_id(table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError("Insert has failed: no such table")

            # 테이블 schema 가져오기
            schema_key = f"__schema__:{table_id}".encode()
            schema_value = self.meta_db.get(schema_key, txn=txn)
            if not schema_value:
                raise MyTransformerError("Fatal Error: Table ID exist, but schema does not exist.")
            schema_column_types = schema_value.decode().split("|")
            schema_column_types = {col.split(":")[0]: col.split(":")[1] for col in schema_column_types}
            
            # NOT NULL 컬럼 가져오기
            constraints_key = f"__constraints__:{table_id}".encode()
            constraints_value = self.meta_db.get(constraints_key, txn=txn)
            not_null_columns = []
            if constraints_value:
                constraints_value = constraints_value.decode().split("|")
                not_null_columns = [c.split(":")[1] for c in constraints_value if c.startswith("NOT NULL:")][0].split(",")

            # 입력된 값 추출
            
            values = [child.children[0] for child in items[5].find_data("column_value")]
            # 명시적으로 입력된 컬럼 순서 확인
            if items[3]:
                # 명시적으로 입력된 컬럼 이름 추출
                new_schema_columns = items[3].find_data("column_name")
                new_schema_columns = [col.children[0].lower() for col in new_schema_columns]

                # 입력된 컬럼이 스키마에 존재하는지 확인
                for col in new_schema_columns:
                    if col not in schema_column_types.keys():
                        raise MyTransformerError(f"Insert has failed: column '{col}' does not exist in table '{table_name}'")

                # 컬럼 개수와 값 개수 확인
                if len(new_schema_columns) != len(values):
                    raise MyTransformerError("Insert has failed: column count does not match value count")

                # 스키마 순서에 맞게 values 재정렬
                reordered_values = []
                for schema_col in schema_column_types.keys():
                    if schema_col in new_schema_columns:
                        # 명시적으로 입력된 컬럼의 값을 가져옴
                        index = new_schema_columns.index(schema_col)
                        reordered_values.append(values[index])
                    else:
                        # 명시적으로 입력되지 않은 컬럼은 NULL로 처리
                        reordered_values.append("null")
                values = reordered_values

            # 컬럼 개수와 값 개수 확인
            if len(schema_column_types) != len(values):
                raise MyTransformerError("Insert has failed: column count does not match value count")

            # 값 검증 및 변환
            for (column_name, column_type), value in zip(schema_column_types.items(), values):
                # NOT NULL 확인
                if column_name in not_null_columns and value.lower() == "null":
                    raise MyTransformerError(f"Insert has failed: column '{column_name}' cannot be NULL")

                # 데이터 타입 확인 및 변환
                if column_type.startswith("char"):
                    max_length = int(column_type.split("(")[1].split(")")[0])
                    if len(value) > max_length:
                        value = value[:max_length]  # 문자열 자르기
                elif column_type == "int":
                    if not value.isdigit():
                        raise MyTransformerError(f"Insert has failed: column '{column_name}' expects an integer")
                    value = int(value)

            # 테이블 데이터베이스 열기
            table_db = db.DB(self.db_env)
            table_db.open(table_id, None, dbtype=db.DB_HASH, txn=txn)

            # 데이터 삽입
            table_db.put("|".join(values).encode() , "|".join(values).encode(), txn=txn)

            # 트랜잭션 커밋
            txn.commit()
            prompt()
            print("The row is inserted")
            table_db.close()

        except MyTransformerError as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)
        except Exception as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(f"Failed to insert row: {e}")
            raise
    
    def delete_query(self, items):
        prompt()
        print("\'DELETE\' requested")
        return
    
    def select_query(self, items):


        txn = self.db_env.txn_begin()
        try:
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, db.DB_BTREE, txn=txn)
            # 컬럼 이름 추출
            select_list = items[1]
            if(select_list.children ==[]):
                
                # 테이블 이름 추출
                reffered_tables = items[2].children[0].children[1].find_data("referred_table")

                for reffered_table in reffered_tables:
                    table_name = reffered_table.children[0].children[0].lower()
                    # 테이블 ID 가져오기
                    try:
                        table_id = self._get_table_id(table_name, txn)
                    except MyTransformerError as e:
                        raise MyTransformerError(f"Select has failed: '{table_name}' does not exist")
                    schema_key = f"__schema__:{table_id}".encode()
                    schema_value = self.meta_db.get(schema_key, txn=txn)
                    if not schema_value:
                        raise MyTransformerError("Fatal Error: Table ID exist, but schema does not exist.")
                    
                    schema_column_types = schema_value.decode().split("|")
                    schema_column_types = {col.split(":")[0]: col.split(":")[1] for col in schema_column_types}
                    

                    # 테이블 데이터베이스 열기
                    table_db = db.DB(self.db_env)
                    table_db.open(table_id, None, dbtype=db.DB_HASH, txn=txn)

                    # 데이터 조회
                    cursor = table_db.cursor(txn=txn)
                    
                    cnt=0
                    formatted = []
                    print(f"-"*len(schema_column_types)*23)
                    if record := cursor.next():
                        for schema_column in schema_column_types.keys():   
                            formatted.append(f" {schema_column[:20]:<20} ")
                        print("|".join(formatted))

                        formatted.clear()
                        for value in record[1].decode().split("|"):
                            formatted.append(f" {value[:20]:<20} ")
                        print("|".join(formatted))
                        cnt+=1
                    while record := cursor.next():
                        formatted.clear()
                        for value in record[1].decode().split("|"):
                            formatted.append(f" {value[:20]:<20} ")
                        print("|".join(formatted))
                        cnt+=1

                    cursor.close()

                    print(f"-"*len(schema_column_types)*23)
                    print(f"{cnt} rows in set")
            else:
                raise MyTransformerError("Select has failed: '*' is only supported")
            

            txn.commit()
            table_db.close()
            self.meta_db.close()
        except MyTransformerError as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)

        return
    
    def show_tables_query(self, items):

        txn = self.db_env.txn_begin()
        try:
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, db.DB_BTREE, txn=txn)

            # 모든 테이블 이름 가져오기
            cursor = self.meta_db.cursor(txn=txn)
            table_names = []
            while record := cursor.next():
                key = record[0].decode()
                if key.startswith("__table_id__:"):
                    table_name = key.split(":")[1]
                    table_names.append(table_name)
            cursor.close()

            # 출력
            print(f"-"*22)
            if table_names:
                for table_name in table_names:
                    print(f" {table_name[:20]:<20} ")
            print(f"-"*22)
            print(f"{len(table_names)} rows in set")

            txn.commit()
            self.meta_db.close()

        except Exception as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(f"Failed to show tables: {e}")
            raise
        
    def update_query(self, items):
        prompt()
        print("\'UPDATE\' requested")
        return
    def rename_query(self, items):

        txn = self.db_env.txn_begin()
        try:
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, db.DB_BTREE, txn=txn)

            # 기존 테이블 이름과 새로운 테이블 이름 추출
            old_table_name = items[1].children[0].children[0].children[0].lower()
            new_table_name = items[1].children[0].children[2].children[0].lower()

            # 기존 테이블 존재 여부 확인
            try:
                table_id = self._get_table_id(old_table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError(f"Rename table has failed: no such table")

            # 새로운 테이블 이름 중복 확인
            try:
                self._check_table_existence(new_table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError(f"Rename table has failed: {e}")
            
            # 기존 테이블 ID 지우기
            old_table_id_key = f"__table_id__:{old_table_name}".encode()
            self.meta_db.delete(old_table_id_key, txn=txn)

            # 새로운 테이블 ID 저장
            new_table_id_key = f"__table_id__:{new_table_name}".encode()
            self.meta_db.put(new_table_id_key, table_id.encode(), txn=txn)

           
            # 트랜잭션 커밋
            txn.commit()
            prompt()
            print(f"'{new_table_name}' is renamed")
            self.meta_db.close()

        except MyTransformerError as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)
        except Exception as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(f"Failed to rename table: {e}")
            raise
        return

    def truncate_query(self, items):

        txn = self.db_env.txn_begin()
        try:
            self.meta_db = db.DB(self.db_env)
            self.meta_db.open("__meta__", None, db.DB_BTREE, txn=txn)

            # 테이블 이름 추출
            table_name = items[1].children[0].lower()

            # 테이블 ID 가져오기
            try:
                table_id = self._get_table_id(table_name, txn)
            except MyTransformerError as e:
                raise MyTransformerError(f"Truncate table has failed: no such table")

            # 테이블 존재 여부 확인
            schema_key = f"__schema__:{table_id}".encode()
            if not self.meta_db.get(schema_key, txn=txn):
                raise MyTransformerError("Fatal Error: Table ID exist, but schema does not exist.")

            # 다른 테이블이 foreign key로 참조하고 있는지 확인
            if self._is_table_referenced(table_id, txn):
                raise MyTransformerError(f"Truncate table has failed: '{table_name}' is referenced by another table")

            # 테이블 데이터베이스 열기
            table_db = db.DB(self.db_env)
            table_db.open(table_id, None, dbtype=db.DB_HASH, txn=txn)

            # 테이블 데이터 삭제
            cursor = table_db.cursor(txn=txn)
            while record := cursor.next():
                table_db.delete(record[0], txn=txn)
            cursor.close()

            # 트랜잭션 커밋
            txn.commit()
            prompt()
            print(f"'{table_name}' is truncated")
            table_db.close()
            self.meta_db.close()

        except MyTransformerError as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(e)
        except Exception as e:
            txn.abort()
            self.meta_db.close()
            prompt()
            print(f"Failed to truncate table: {e}")
            raise
    def EXIT(self, items):
        self.db_env.close()
        exit()
        return
    



def main():

    #Lark parser 생성
    
    with open('grammar.lark') as file:
        sql_parser = lark.Lark(file.read(), start="command", lexer="basic")
    
   

    sql_transformer = MyTransformer()

    while True:

        query=get_query()

        try:
            # 전체 쿼리를 한 번에 파싱
            output = sql_parser.parse(query)
            sql_transformer.transform(output)

        except lark.exceptions.UnexpectedInput as e:
            
            valid_query=get_valid_query(query, e)
            
            try:
                # 오류 이전의 query만 실행
                output = sql_parser.parse(valid_query)
                sql_transformer.transform(output)

                # 오류가 발생한 query에 대한 Syntax error 출력
                prompt()
                print("Syntax error")

            # valid_query도 에러가 발생하는 경우
            # ex) 첫 번째 query가 에러가 발생하는 경우 valid_query가 ' ; '이므로 에러 발생
            except lark.LarkError as e:

                # Syntax error 출력
                prompt()
                print("Syntax error")
        except Exception as e:
            # 기타 에러 처리
            prompt()
            print(f"Error: {e}")
      
            
              
    return


main()

